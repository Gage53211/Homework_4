# graphs_gmather2

The primary purpose of this package is to allow the user to install and use an implementation of Dijkstra's Shortest Path which is an algorithm that finds the shortest path between a source vertex and a target vertex in an undirected graph.

# Usage:

this package comes with one methed called dijkstra which returns two values, the distance to the target vertex from the source vertex which is an integer value, and the path that the algorithm took in order to reach the target vertex from the source vertex

```
dijkstra(graph, source) 
```




